#!/bin/sh
# Rewrites the body of each past release with its regenerated notes.
# Run from this directory: sh apply.sh
set -e
for f in v*.md; do
  tag=${f%.md}
  gh -R open-conduit/open-conduit release edit "$tag" --notes-file "$f"
  echo "updated $tag"
done
